# About me

A Pen created on CodePen.io. Original URL: [https://codepen.io/daveclarkecodes/pen/qBogoWv](https://codepen.io/daveclarkecodes/pen/qBogoWv).

An about me page i made while doing the w3c course CSS basics.